
def q2(S):
    all_seq = []

    for seed in range(256):
        
        lfsr = LFSR(bin(seed)[2:].zfill(8))
        seq = []

        found = False

        while True:
            lfsr.step()
            seq.append(lfsr.bit[7])
            if len(seq) == len(S):
                if seq == S:
                    found = True
                break
        
        if found:
            print(bin(seed)[2:].zfill(8))
            break

#根據上課給的提示，已知生成多項式是x^8+x+1
class LFSR:
    def __init__(self, seed):
        self.num = int(seed)
        self.bit = [int(i) for i in list(seed)]
        #print(self.seq)

    def step(self):
        b1 = self.bit[0]
        b2 = self.bit[1]
        #b2 = self.bit[2]
        #b3 = self.bit[3]
        #b4 = self.bit[4]
        self.bit.pop(0)
        self.bit.append(b1 ^ b2)
        #self.bit.append(b1 ^ b2 ^ b3 ^ b4)
        self.num = (self.num % 1e7) * 10 + self.bit[7]

if __name__ == '__main__':
    
    all_seq = []
    all_bit_set = set()

    for seed in range(256):
        
        lfsr = LFSR(bin(seed)[2:].zfill(8))
        seq = []

        while True:
            lfsr.step()
            if lfsr.num not in all_bit_set:
                all_bit_set.add(lfsr.num)
                seq.append(lfsr.bit[7])
            else:
                break

        if seq:
            all_seq.append(seq)
    '''
    for x in all_seq:
        print(x)
        print(len(x))
    '''

    cypher = [  1,1,0,0,0,1,1,1, 1,1,0,0,1,1,1,0, 1,1,0,0,0,1,1,0, 1,1,0,1,0,1,0,0, 1,1,0,0,1,0,0,1, 
                1,1,0,0,1,1,1,1, 1,1,1,0,1,1,1,1, 1,0,1,1,0,0,0,0, 0,1,0,1,0,1,0,0, 0,1,0,1,0,0,0,1, 
                0,1,0,0,0,0,1,0, 0,1,0,1,1,1,0,1, 0,1,0,1,0,0,0,0, 0,1,1,1,0,0,0,0, 0,0,0,1,1,1,0,0, 
                1,0,1,1,0,0,0,1, 0,1,0,1,0,1,1,1, 0,1,0,1,0,1,0,1, 0,1,0,1,1,0,1,1, 0,1,0,0,1,0,1,1, 
                0,1,1,0,0,1,1,1, 0,0,1,0,0,0,1,1, 1,1,1,0,0,1,0,1   ]
    '''
    for i in range(len(cypher)):
        if i % 8 == 0:
            print(cypher[i], end = " ")
    '''

    all_ok = []

    for x in all_seq:
        for idx in range(len(x)):
            ok = True
            tmpx = x[idx:] + x[:idx]
            for i in range(len(cypher)):
                if i % 8 == 0 and tmpx[i % len(x)] != cypher[i]:
                    ok = False
                    break
            if ok:
                all_ok.append(tmpx)

    #print(all_ok)

    S = []
    if len(all_ok) == 1:
        S = all_ok[0]
    else:
        print("oh no!")

    num = 0
    for i in range(len(cypher)):
        num += (cypher[i] ^ S[i%len(S)]) * pow(2, 7-i%8)
        if (i % 8 == 0 and i != 0) or i == len(cypher)-1:
            print(chr(num), end="")
            num = 0
    '''
    print()
    q2(S)
    '''

