import numpy as np

def BM(a):
    d = [0] * len(a)     #delta
    f = []          #fail
    r = []
    c = 0           #cnt

    for i in range(len(a)):
        print("i = " + str(i))
        d[i] = a[i]
        if c > 0:
            ar = a[i-len(r[-1]):i]
            ar.reverse()
            d[i] = a[i] - np.dot(np.array(r[-1]), np.array(ar))
        
        if d[i] != 0:
            f.append(i)
            r_ = [0]
            r_last = [0]
            if c != 0:
                mul = d[i] / d[f[c-1]]
                print("f[c-1] = " + str(f[c-1]))
                r_ = [0]*(i-f[c-1]-1) + [mul] + [-x * mul for x in r[c-2]]
                print("r_ = " + str(r_))
                r_last = r[-1] + [0] * (len(r_) - len(r[-1]))
            r_ = np.array(r_)
            print("len(r_) = " + str(len(r_)))
            r_last = np.array(r_last)
            r_nxt = r_last + r_
            r.append(r_nxt.tolist())
            c += 1

        if len(r) > 0:
            print(r[-1])

    return r[-1]

def printpoly(r):
    '''
    n = len(r)
    for i in range(n):
        print(str(r)+"*x^"+str())
    '''
    print(r)

if __name__ == '__main__':
    seq1 = [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0,
            1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0,
            1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1,
            0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1]
    r1 = BM(seq1)
    printpoly(r1)

    """
    seq2 = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
    r2 = BM(seq2)
    printpoly(r2)
    """

    """
    seq3 = [1, 2, 4, 9, 20, 40, 90]
    r3 = BM(seq3)
    printpoly(r3)
    """
    

