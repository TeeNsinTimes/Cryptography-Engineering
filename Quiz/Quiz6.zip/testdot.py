import numpy as np

a1 = np.array([5, 6])
a2 = np.array([1,2,3])
print(a2[2::-1])
