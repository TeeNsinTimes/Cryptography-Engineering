import numpy as np

def BM(a, mod2):
    d = [0] * len(a)     #delta
    f = []          #fail
    r = []
    c = 0           #cnt

    for i in range(len(a)):
        d[i] = a[i]
        if c > 0:
            ar = a[i-len(r[-1]):i]
            ar.reverse()
            if mod2:
                d[i] = a[i] - np.dot(np.array(r[-1]), np.array(ar))%2
            else:
                d[i] = a[i] - np.dot(np.array(r[-1]), np.array(ar))
        
        if d[i] != 0:
            f.append(i)
            r_ = [0]
            r_last = [0]
            if c != 0:
                mul = d[i] / d[f[c-1]]
                if c - 2 < 0:
                    r_ = [0]*(i-f[c-1]-1) + [mul]
                else:
                    r_ = [0]*(i-f[c-1]-1) + [mul] + [-x * mul for x in r[c-2]]

                r_last = r[-1]
                if len(r_last) < len(r_):
                    r_last = r_last + [0] * (len(r_) - len(r_last))
                elif len(r_) < len(r_last):
                    r_ = r_ + [0] * (len(r_last) - len(r_))
            r_ = np.array(r_)
            r_last = np.array(r_last)
            r_nxt = r_last + r_
            r.append(r_nxt.tolist())
            c += 1

    return r[-1]

def printLFSR(r):
    print("x^" + str(len(r)), end = "")
    
    for i in range(len(r)):
        if r[i] != 0:
            if i != len(r)-1:
                print(" + x^"+str(len(r)-i-1), end = "")
            else:
                print(" + 1", end = "")
    print()

if __name__ == '__main__':
    mod2 = True
    seq1 = [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0,
            1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0,
            1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1,
            0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1]
    r1 = BM(seq1, mod2)
    printLFSR(r1)

    mod2 = False
    seq2 = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
    r2 = BM(seq2, mod2)
    print(r2)
    

