import numpy
import math

a = input()
f1 = "".join(open(a, "r").read().split())

l1 = -1
l2 = -1

tri = numpy.zeros((26, 26, 26))
bi = numpy.zeros((26, 26))

for x in f1:
    l = ord(x) - ord('A')
    if l1 == -1:
        l1 = l
    elif l2 == -1:
        l2 = l
    else:
        tri[l1][l2][l] += 1
        bi[l1][l2] += 1
        l1 = l2
        l2 = l

b = input()
f2 = "".join(open(b, "r").read().split())

#For testdata2.txt, it contains 77 letters, so it might be 7*11, or 11*7
#Already know first 3 letters are "GRE"
#-> only 11*7 can make the only 'G' at the beginning
#-> All first chars are 'E', 'E', 'G', 'A', 'E', 'R', 'C'
#-> Cannot decide which 'E' is the correct 'E'
#-> Compare the rest chars in these columns

c1 = 2
c2 = 5

seq = [2, 5]
#Decide the rest
rest = [0, 1, 3, 4, 6]

while (rest):
    mx_idx = -1
    mx_prob = 0
    for i in rest:
        w = 0
        for j in range(11):
            l1 = ord(f2[c1 * 11 + j]) - ord('A')
            l2 = ord(f2[c2 * 11 + j]) - ord('A')
            l3 = ord(f2[i * 11 + j]) - ord('A')
            if tri[l1][l2][l3] == 0:
                continue
            w += math.log(26 * tri[l1][l2][l3] / bi[l1][l2])
        if w > mx_prob:
            mx_prob = w
            mx_idx = i
    c1 = c2
    c2 = mx_idx
    seq.append(mx_idx)
    rest.remove(mx_idx)

for j in range(11):
    for i in seq:
        print(f2[i * 11 + j], end="")

#GREECEANNOUNCEDYESTERDAYITHADREACHEDAGREEMENTWITHTURKEYTOENDTHECYPRUSCRISISNS
#GREECE ANNOUNCED YESTERDAY IT HAD REACHED AGREEMENT WITH TURKEY TO END THE CYPRUS CRISIS NS