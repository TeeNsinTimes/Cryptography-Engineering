import secrets

if __name__ == '__main__':
    
  with open('secrets.bin', 'w+b') as file:
    for i in range(100000000):
      x = int.from_bytes(secrets.token_bytes(), byteorder='big') & 1
      if x == 0:
        file.write(b'0')
      else:
        file.write(b'1')