#include <bits/stdc++.h>
using namespace std;

int main() {
    double k = 1;
    for (double i = 364; i >= 316; --i) {
        k *= i / 365;
    }
    cout << 1 - k << endl;
}