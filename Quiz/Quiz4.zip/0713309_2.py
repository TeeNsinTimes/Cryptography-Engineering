class LFSR:
    def __init__(self, seq):
        self.seq = [int(i) for i in list(seed)]
        #print(self.seq)

    def step1(self):
        b1 = self.seq[2]
        b2 = self.seq[3]
        for i in range(3):
            self.seq[3 - i] = self.seq[3 - i - 1]
        self.seq[0] ^= (b1 ^ b2)
    
    def step2(self):
        b1 = self.seq[2]
        b2 = self.seq[4]
        for i in range(3):
            self.seq[4 - i] = self.seq[4 - i - 1]
        self.seq[1] ^= self.seq[0]
        self.seq[0] ^= (b1 ^ b2)

    def step3(self):
        b1 = self.seq[0]
        b2 = self.seq[3]
        for i in range(3):
            self.seq[3 - i] = self.seq[3 - i - 1]
        self.seq[0] = (b1 ^ b2)

    def print(self):
        for x in self.seq:
            print(x, end = "")
        print(" ", end = "")
        print(self.seq[-1])

if __name__ == '__main__':
    seed = "1111" 
    lfsr1 = LFSR(seed)
    
    set1 = set()
    while not ''.join(str(x) for x in lfsr1.seq) in set1:
        set1.add(''.join(str(x) for x in lfsr1.seq))
        lfsr1.step1()
        lfsr1.print()

    seed = "11111" 
    lfsr2 = LFSR(seed)
    
    set2 = set()
    while not ''.join(str(x) for x in lfsr2.seq) in set2:
        set2.add(''.join(str(x) for x in lfsr2.seq))
        lfsr2.step2()
        lfsr2.print()

    mx = 0
    for i in range(16):
        seed = str("{0:b}".format(i))
        while len(seed) < 4:
            seed = "0" + seed
        #print(seed)
        lfsr3 = LFSR(seed)
        
        set3 = set()
        while not ''.join(str(x) for x in lfsr3.seq) in set3:
            set3.add(''.join(str(x) for x in lfsr3.seq))
            lfsr3.step1()
            #print(lfsr3.seq)
        mx = max(mx, len(set3))
    
    print("max_len =", mx)

    seeds = ["1000", "1111", "0110"]
    for seed in seeds:
        print("for seed", seed)
        lfsr4 = LFSR(seed)
    
        set4 = set()
        while not ''.join(str(x) for x in lfsr4.seq) in set4:
            set4.add(''.join(str(x) for x in lfsr4.seq))
            lfsr4.step3()
            lfsr4.print()
