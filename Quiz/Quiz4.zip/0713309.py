class LFSR:
    def __init__(self, tap, seq):
        self.tap = tap
        self.seq = [int(i) for i in list(seed)]
        #print(self.seq)

    def step(self):
        b1 = self.seq[0]
        b2 = self.seq[len(self.seq) - self.tap - 1]
        self.seq.pop(0)
        self.seq.append(b1 ^ b2)

    def print(self):
        for x in self.seq:
            print(x, end = "")
        print(" ", end = "")
        print(self.seq[-1])

if __name__ == '__main__':
    tap  = int(input("tap = "))
    seed  = str(input("seed = "))

    lfsr = LFSR(tap, seed)
    
    for i in range(10):
        lfsr.step()
        lfsr.print()
    