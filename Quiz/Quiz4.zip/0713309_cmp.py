from PIL import Image

f1  = "pipe.png"
img1 = Image.open(f1)

f2 = "pipe1.png"
img2 = Image.open(f2)

if img1 == img2:
    print("pipe.png = pipe1.png")
else:
    print("pipe.png != pipe1.png")

f3  = "Xpipe.png"
img3 = Image.open(f3)

f4 = "Xpipe1.png"
img4 = Image.open(f4)

if img3 == img4:
    print("Xpipe.png = Xpipe1.png")
else:
    print("Xpipe.png != Xpipe1.png")
