import numpy as np
from PIL import Image

test_bit = 0 #When doing the output, test_bit = 1 will add "1" after file_name for testing

class LFSR:
    def __init__(self, tap, seq):
        self.tap = tap
        self.seq = [int(i) for i in list(seed)]
        #print(self.seq)

    def step(self):
        b1 = self.seq[0]
        b2 = self.seq[len(self.seq) - self.tap - 1]
        self.seq.pop(0)
        self.seq.append(b1 ^ b2)

    def print(self):
        for x in self.seq:
            print(x, end = "")
        print(" ", end = "")
        print(self.seq[-1])

if __name__ == '__main__':
    #open .png file and then transform it to [H][W][4] array
    file_name  = str(input("file name : "))
    img = Image.open(file_name)
    arr = np.array(img)
    
    #tap & seed
    tap  = int(input("tap = "))
    seed  = str(input("seed = "))

    lfsr = LFSR(tap, seed)

    #Transfer
    for j in range(img.size[0]):
        for i in range(img.size[1]):
            for k in range(3):
                color = [int(x) for x in list(str("{0:b}".format(arr[i][j][k])))]

                while len(color) < 8:
                    color = [0] + color

                for l in range(8):
                    lfsr.step()
                    color[l] ^= lfsr.seq[-1]
                
                arr[i][j][k] = int(''.join(str(x) for x in color), 2)

    #Output
    new_img = Image.fromarray(arr)
    file_name = "pipe" if file_name[0] == "X" else "Xpipe"
    if test_bit == 1:
        file_name += "1"
    new_img.save(file_name + ".png")

    #print("Saved")
                