Instructions for starting the AIS 31 implementation in JAVA:
-------------------------------------------------- -----

Requirements:
  - JavaVM version 1.3.1 or higher is installed
  (This or a newer version is available for download from java.sun.com; select and download Java2SE here)
  - "Tester.class" file
  - "Evaluator.class" file (Both files must be in the same Directory.)

Start under Microsoft Windows:
  As a rule, the JavaVM creates some system variables when it is installed,
  which make it possible to access the java.exe file on the command line from any location to execute.
  If this does NOT work for you,
  - Please search for the "java.exe" file with the Windows search program
  - Open the command line
    (under Windows95 / 98 / Me in the menu Start -> Run -> "command.com",
    under WindowsNT / 2000 / XP in the menu Start -> Run -> "cmd")
  - Start the program with the following command:

java.exe -classpath "[CLASS FILES DIRECTORY]" Evaluator
  For example, if the two class files are in the "Ais31" folder on the Partition "C:",
  the command is as follows:
    java.exe -classpath "C: \ Ais31" Evaluator

  It is IMPERATIVE to make sure that the first letter of the word "evaluator" big and the rest are small.
  Otherwise the program will not start.

  Of course, you can also use the java.exe command in the "Execute" -
  Enter dialogue. However, you will then see at least under Windows NT / 2000 / XP
  any command line errors are not, as these systems do not
  Immediately hide the command line program after it has ended.

  Of course, you do not have to do this every time you call the test program to repeat.
  You can also save the above command to a batch file or
  write a shortcut and run the application with a double click.

First steps:
---------------

After calling the program as described above, you have to
make the following settings before executing it:

  In the entry line, enter the name and path of the file that contains the contains random numbers to be tested.

  Select one of the three test classes (P1: T0; P1: T1-T5; P2-specific).

  Choose the detailed or the normal output format.

  Specify the form in which the random numbers are stored in the file to be tested are.
  There are two options to choose from:
  - The binary representation of each random byte is presented as a sequence of 8 random bits
    interpreted. The most significant bit is interpreted as the oldest bit.
  - The file contains a sequence of zeros and ones. Then each random byte corresponds a random bit.
  Note: Note that the program has a minimum number of random bits needed to run the tests.
  If the setting "1 random bit per byte" is selected, the file to be read must be correspondingly longer.

  Indicate whether the test is being carried out for the first time (normal test) or whether it is is a repeat test.
  Note: Each random bit is only tested once.
  The remaining random bits of the input file are stored in a new file saved.
  The program uses this residual file by default for the next test.

  Enter the width of the internal random numbers in bits (e.g. 8, 16 or 64).

  Start the statistical tests by clicking the start field.
  The test results are displayed in the output area.