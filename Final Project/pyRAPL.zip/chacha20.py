import os
from Crypto.Cipher import ChaCha20
import pyRAPL

pyRAPL.setup()

csv_output = pyRAPL.outputs.CSVOutput('chacha20_result.csv')

@pyRAPL.measureit(number=100, output=csv_output)
def chacha_once():
  plaintext = b'test'
  key = os.urandom(32)
  nonce = os.urandom(12)

  encoder = ChaCha20.new(key=key, nonce=nonce)
  ciphertext = encoder.encrypt(plaintext)

  decoder = ChaCha20.new(key=key, nonce=nonce)
  plaintext = decoder.decrypt(ciphertext)

for _ in range(100):
  chacha_once()

csv_output.save()