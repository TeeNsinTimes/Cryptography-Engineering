from Crypto.Cipher import AES
import os
import pyRAPL

pyRAPL.setup()

csv_output = pyRAPL.outputs.CSVOutput('AES256_8byte_nonce_result.csv')

@pyRAPL.measureit(number=100, output=csv_output)
def AES256_once():
  plaintext = b'test'
  key = os.urandom(32)
  nonce = os.urandom(16)
  encoder = AES.new(key, AES.MODE_EAX, nonce=nonce)
  ciphertext = encoder.encrypt(plaintext)
  decoder = AES.new(key, AES.MODE_EAX, nonce=nonce)
  plaintext = decoder.decrypt(ciphertext)

for _ in range(100):
  AES256_once()

csv_output.save()