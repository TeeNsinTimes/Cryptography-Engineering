import os
from Crypto.Cipher import ChaCha20_Poly1305
import pyRAPL

pyRAPL.setup()

csv_output = pyRAPL.outputs.CSVOutput('chacha20_poly1305_result.csv')

@pyRAPL.measureit(number=100, output=csv_output)
def chacha_once():
  plaintext = b'test'
  key = os.urandom(32)
  nonce = os.urandom(12)

  encoder = ChaCha20_Poly1305.new(key=key, nonce=nonce)
  ciphertext = encoder.encrypt(plaintext)
  
  decoder = ChaCha20_Poly1305.new(key=key, nonce=nonce)
  plaintext = decoder.decrypt(ciphertext)

for _ in range(100):
  chacha_once()

csv_output.save()