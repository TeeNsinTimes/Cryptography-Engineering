from Crypto.Cipher import Salsa20
import os
import pyRAPL

pyRAPL.setup()

csv_output = pyRAPL.outputs.CSVOutput('salsa20_result.csv')

@pyRAPL.measureit(number=100, output=csv_output)
def salsa_once():
	plaintext = b'test'
	secret = os.urandom(32)
	nonce = os.urandom(8)
	encoder = Salsa20.new(key=secret, nonce=nonce)
	ciphertext = encoder.encrypt(plaintext)
	decoder = Salsa20.new(key=secret, nonce=nonce)
	plaintext = decoder.decrypt(ciphertext)

for _ in range(100):
    salsa_once()

csv_output.save()