from randomgen import ChaCha

sz = int(512000*33/(64/8))
with open('sts-2.1.2/chacha20.bin', 'w+b') as file:
  key_stream = ChaCha(rounds=20).random_raw(size=sz)
  file.write(key_stream)